<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from pixner.net/cardzone/cardzone/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 13 May 2024 05:02:56 GMT -->
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Naman Services</title>
   <!--Favicon img-->
   <link rel="shortcut icon" href="assets/img/logo/favicon.png">
   <!--Bootstarp min css-->
   <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   <!--Bootstarp map css-->
   <link rel="stylesheet" href="assets/css/bootstrap.css.map">
   <!--Odometer css-->
   <link rel="stylesheet" href="assets/css/odometer.css">
   <!--Animate css-->
   <link rel="stylesheet" href="assets/css/animate.css">
   <!--Magnifiq Popup css-->
   <link rel="stylesheet" href="assets/css/magnific-popup.css">
   <!--All min css-->
   <link rel="stylesheet" href="assets/css/all.min.css">
   <!--Owl Carousel min css-->
   <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
      <!--Owl Carousel theme css-->
   <link rel="stylesheet" href="assets/css/owl.theme.default.css">
   <!--Owl Nice select css-->
   <link rel="stylesheet" href="assets/css/nice-select.css">
   <!--Glyphter icon css-->
   <link rel="stylesheet" href="assets/css/google-font.css">
   <!--Date Ranger css-->
   <link rel="stylesheet" href="assets/css/daterangepicker.css">
   <!--main css-->
   <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>

<!-- Preloader Start Here -->
<div class="preloader__wrap">
   <div class="preloader__box">
      <div class="circle">
        Naman Services
         <!-- <img src="assets/img/logo/nslogo.png" alt="preloader"> -->
      </div>
      <div class="recharge">
         <!-- <img src="assets/img/logo/rechage.png" alt="rechage"> -->
      </div>
      <!-- <span class="pretext">
         Naman Services
      </span> -->
   </div>
</div>
<!-- Preloader End Here -->   

<!-- Header Here -->
<header class="header-section bgadd ">
   <div class="container">
      <div class="header-wrapper">
         <div class="logo-menu">
            <a href="index.php" class="logo">
               <img src="assets/img/logo/nslogo.png" alt="logo" style="height: 83px;">
            </a>
            <a href="index.php" class="small__logo d-xl-none">
               <img src="assets/img/logo/favicon.png" alt="logo">
            </a>
         </div>
         <ul class="main-menu">
            <li>
               <a href="javascript:void(0)" class="fz-24">
                  Home 
                 
               </a>
               <!-- <ul class="sub-menu">
                  <li>
                     <a href="index.html">Home [1]</a>
                  </li>
                  <li>
                     <a href="index-2.html">Home [2]</a>
                  </li>
               </ul> -->
            </li>
            <li>
               <a href="service.php">
                  Our Services 
                  
               </a>
               
            </li>
           
            <li class="subtwohober">
               <a href="about.php">About Us</a>
            </li>
            <li>
               <a href="packege.php">
                  Packeges
               </a>
            </li>
            <li>
               <a href="contact.php">
                  Contact Us
               </a>
            </li>
            <li>
               <a href="#">
                  <button type="button" class="newbtn">

                     Call- +919297517222
                  </button>
               </a>
            </li>
          
         </ul>
        
      </div>
   </div>
</header>